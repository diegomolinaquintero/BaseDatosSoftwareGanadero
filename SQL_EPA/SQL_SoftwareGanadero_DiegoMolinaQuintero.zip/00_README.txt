HOla soy Diego MOlina

Estas son las sentencias SQL.
Estan separadas segun los puntos del taller.
01 creacion de base de datos deberia ser la primera en ejecutarse
02 insertar los datos 
03 y 04 son las consultas requeridas 
05 es para eliminar  un animal o un usuario
06 actualizar 

Nota : el trigger esta en el archivo 01_base_datos.sql al final
 