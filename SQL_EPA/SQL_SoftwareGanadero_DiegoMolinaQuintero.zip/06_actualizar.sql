-- un animaldenovillo(a) a toro o vaca
UPDATE ganado SET ganado.id_tipoganado = 2 WHERE ganado.id = 1 ;
-- contraseña de un usuario del sistema
UPDATE usuarios SET usuarios.password = "julianito2021" WHERE usuario.id = 11 ;

